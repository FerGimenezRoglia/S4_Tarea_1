package excepciones;

public class InvalidIllustrationException extends RuntimeException {
    public InvalidIllustrationException(String message) {
        super(message);
    }
}
