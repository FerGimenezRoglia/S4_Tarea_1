import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int option;

        do {
            System.out.println(" ");
            System.out.println("1. ");
            System.out.println("2. ");
            System.out.println("3. ");
            System.out.println("4. ");
            System.out.print( (" ");
            option = scanner.nextInt();
            scanner.nextLine();

            switch (option) {
                case 1:
                    registrarIlustracion(scanner);
                    break;

    }
}